<?php

interface Messagingsms_Multivendor_Interface {
	public function get_vendor_data_list_from_order( $order_id );
}
