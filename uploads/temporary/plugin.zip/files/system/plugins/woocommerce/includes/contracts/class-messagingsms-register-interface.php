<?php
/**
 * Created by PhpStorm.
 * User: Neoson Lam
 * Date: 4/10/2019
 * Time: 2:02 PM.
 */

interface Messagingsms_Register_Interface {
	public function register();
}
